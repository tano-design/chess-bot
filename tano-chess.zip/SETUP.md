# TANOBOT setup: a chess bot that plays like you

Everything runs in the visitor's browser. No API key, no server costs. It gets its own GitHub repo and its own Vercel project, separate from the TanoLLM chatbot.

Total time: about 10 minutes.

## 1. Upload to GitHub (3 min)

In your chess repo, upload these to the **top level** (the repo's front page, not inside another folder):

- the `public` folder (it has `chess/` inside it, plus a tiny `index.html`)
- `vercel.json`
- optional: the `chess-tools` folder (the retrain script) and `SETUP.md`

Tip: on a Mac, Finder hides nothing here, but if you also drag hidden files, press Cmd + Shift + . to show them.

Check: the repo's front page should show `public/` and `vercel.json` side by side, and `public/chess/embed.js` should exist.

## 2. Make a Vercel project for it (3 min)

1. On vercel.com: **Add New… → Project** and import the chess repo.
2. **Framework Preset:** Other. Leave Root Directory, Build and Output settings alone.
3. No environment variables needed. Click **Deploy**.
4. Note your address, e.g. `https://tano-chess.vercel.app` (it's named after the repo).

## 3. Test it (1 min)

Open `https://YOUR-ADDRESS/chess/`. You should see the board and be able to play. The button at the top flips light/dark.

## 4. Put it on Cargo (3 min)

1. **Site Settings → CSS / HTML → HTML**, at the very end (under the TanoLLM line), paste ONE line, with your own Vercel address in it:
   ```
   <script src="https://tano-chess.vercel.app/chess/embed.js" defer></script>
   ```
   Keep `/chess/embed.js` on the end. It's 1 KB and does nothing on pages without the board.
2. Make a new page (e.g. `/chess` or something sneakier) and set it to hidden / not in the nav.
3. In the page's code view, paste:
   ```
   <div data-tano-chess></div>
   ```
4. Link to it from wherever you want the easter egg.

It follows your site's light/dark toggle and uses your site fonts automatically.

## What's in `public/chess`

| File | What it is | Edit it? |
|---|---|---|
| `tano-chess.js` | The board, the panel, and the "play like tano" logic | Optional: colors, sizes, think time at the top |
| `tano-book.json` | What the bot learned from your games | Replace it when you retrain |
| `embed.js` | The tiny loader Cargo uses | No |
| `chess.js` | Chess rules | No |
| `stockfish.js`, `stockfish.wasm` | The chess engine | No |
| `index.html` | Test page | No |
| `CREDITS.txt`, `STOCKFISH-LICENSE.txt` | Licenses for the engine and pieces | Keep them |

`vercel.json` lets tanodsgn.com load these files from Vercel. Without it the board stays blank on Cargo.

## Retraining

See `chess-tools/README.md`, or just ask Claude to "retrain the chess bot". The new `tano-book.json` goes in `public/chess/` in the chess repo.
